<?php

define('WINICARI_API_BASE', 'https://bus-intelligence.onrender.com');
define('WINICARI_API_KEY', '93a763f2e2fd7365533cc460bdc6cb72');

define('WINICARI_FALLBACK_COMPANIES', [
    'EPE-TVE', 'S.R.T.BIZERTE', 'S.R.T.K', 'S.R.T.M', 'S.R.T.SELIANA', 'S.T.C.I',
    'S.T.S', 'SORETRAS', 'SRT.ELGOUAFEL', 'TCV', 'TUS', 'Winicari',
]);

define('WINICARI_WEBSERVICE_URL', 'http://102.128.57.59:8123');
